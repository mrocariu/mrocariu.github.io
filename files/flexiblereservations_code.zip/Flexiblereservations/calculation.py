# -*- coding: utf-8 -*-
"""
Created on Tue May  1 17:22:39 2018
Define functions for some calculations: median, mean, solving the cplex models, and evaluation
@author: ykaidi
"""
import subprocess
from Constants_car import Constants_car
import os
def median(lst):
    n = len(lst)
    if n < 1:
            return None
    if n % 2 == 1:
            return sorted(lst)[n//2]
    else:
            return sum(sorted(lst)[n//2-1:n//2+1])/2.0
        
def mean(lst):        
    if len(lst)>0:
        return sum(lst)/len(lst)
    else:
        return None
		
def _ss(data):
    #Return sum of square deviations of sequence data.
    c = mean(data)
    ss = sum((x-c)**2 for x in data)
    return ss

def pstdev(data):
    #Calculates the population standard deviation
    n = len(data)
    if n < 2:
        raise ValueError('variance requires at least two data points')
    ss = _ss(data)
    pvar = ss/(float(n)-1) # the population variance
    return pvar**0.5
	
def sobol():
    # sobol sequence for sampling to avoid extreme samples
	s = [];
	with open("sobol.txt",'r') as sobol_file:
		for line in sobol_file:
			s.append(float(line))
	return s

def solve(parameters):
    if len(parameters) == 6:
        mod_path,data_path0,data_path1,data_path2,data_path3,res_path = parameters
    elif len(parameters) ==4:
        mod_path,data_path0,data_path1,res_path = parameters
    elif len(parameters) ==3:
        mod_path,data_path0,res_path = parameters
    my_env = os.environ.copy()
    cons = Constants_car()
    my_env["LD_LIBRARY_PATH"] = cons.CPLEXPATH 
    with open(res_path,'w') as output_f:
        if len(parameters) == 6:
            subprocess.Popen([cons.CPLEXPATH+"oplrun",  cons.HOMEPATH+mod_path, cons.HOMEPATH+data_path3, cons.HOMEPATH+data_path0, cons.HOMEPATH+data_path1, cons.HOMEPATH+data_path2],stdout=output_f,env=my_env)
            subprocess.Popen.wait
        elif len(parameters) ==4:
            subprocess.Popen([cons.CPLEXPATH+"oplrun",  mod_path,data_path1,data_path0],stdout=output_f,env=my_env)
        elif len(parameters) ==3:
            subprocess.Popen([cons.CPLEXPATH+"oplrun",  mod_path,data_path0],stdout=output_f,env=my_env)
    
def evaluation(preAssign, arr, actualAssign, value,lmbd):
    obj = 0
    for r in actualAssign.keys():
        if preAssign[r] >= actualAssign[r]:
            obj = obj + value[r-1][preAssign[r]]
        else:
            obj = obj + value[r-1][actualAssign[r]]
        obj = obj - lmbd*(actualAssign[r]-arr[r])
    return obj
