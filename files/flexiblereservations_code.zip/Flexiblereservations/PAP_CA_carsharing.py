"""
Solving PAP
For Mobility Instances
"""



from multiprocessing import Pool
import itertools
import os
import time
from Constants_car import Constants_car
from calculation import solve
from readFiles import readValue, getNumRQ

# sort valuation vector at each time instant
def sortValue(num,type,value):
    vS = list()
    for v in value:
        vS.append(sorted(range(len(v)), key=lambda k: v[k],reverse=True))

    return vS

# solve the model with algorithm specified by "method"
def solvePAP(dat,mod,method,buffer,c,td):
    cons = Constants_car()
    if not os.path.exists('record/'):
        os.makedirs('record/')
    #record_file = 'record/record'+str(dat)+'_'+mod+'.txt'
    record_file = 'record/record'+str(dat)+'.txt'
    
    data_file0 = cons.INPUTFILE.format(dat)
    data_file1 = cons.VALUEFILE.format(dat)
    data_file2 = cons.INITFILE.format(dat,mod)
    data_file3 = cons.PATHFILE.format(dat)
    
    if buffer == '':    
        
        modFile = 'main_%s.mod'
        if method == 1:
            mod_file = cons.MODPATH + modFile %'fast'
        elif method ==2:
            mod_file = cons.MODPATH + modFile %'lazy'
        elif method == 3:
            mod_file = cons.MODPATH + modFile %'initial'
        elif method == 4:
            mod_file = cons.MODPATH + modFile %'normal'	
    elif buffer == 'extend1':
        mod_file = cons.MODPATH + 'PAP_CA_1.mod'
    elif method == 'extend2':
        mod_file = cons.MODPATH + 'PAP_CA_2.mod'
    elif 'slack' in method:
        mod_file = cons.MODPATH + 'PAP_CA_slack.mod'
    elif method == 'dynamic':
        mod_file = cons.MODPATH + 'PAP_CA_dynamic.mod'
    elif method == 'dynamic2':
        mod_file = cons.MODPATH + 'PAP_CA_dynamic2.mod'
        
        
    
    with open(data_file3,'w') as file:
        if buffer == '':
            file.write('resultPath="'+cons.HOMEPATH + cons.SOLUTIONPATH + cons.SOLUTIONFILE.format(dat) + '";\r\n')
            file.write('processPath="'+cons.HOMEPATH + cons.SOLUTIONPATH + cons.PROCESSFILE.format(dat) + '";\r\n')
            try:
                if not os.path.exists(cons.SOLUTIONPATH):
                    os.makedirs(cons.SOLUTIONPATH)
            except:
                print('error creating folder ' + cons.SOLUTIONPATH)
        else:
            file.write('path="'+cons.HOMEPATH + cons.BUFFERPATH.format(buffer) + cons.SOLUTIONFILE.format(dat) + '";\r\n')
            try:
                if not os.path.exists(cons.BUFFERPATH.format(buffer)):
                    os.makedirs(cons.BUFFERPATH.format(buffer))
            except:
                print('error creating folder ' + cons.BUFFERPATH.format(buffer))
                
    #print os.path.exists(my_env["LD_LIBRARY_PATH"]+"oplrun"),my_env["LD_LIBRARY_PATH"]+"oplrun"
    	solve((mod_file,data_file0,data_file1,data_file2,data_file3,record_file))
	#solve((mod_file,data_file0,data_file1,record_file))
        #p.wait()

# write initial values
def initWrite(dat,mod,z,value,sortValueIndex,c,td):
    cons = Constants_car()
    zinit = []	
    for i in range(len(z)):
        zz = [0]*(cons.timeNum+50)
        zinit.append(zz)
    n = len(z)
    assignTime = [-1]*n
    flag =True
    while flag:
        flag = False
        for i in range(0,len(z)):
            for t in range(0,cons.timeNum):
                if assignTime[i]>=0 and value[i][sortValueIndex[i][t]]<=value[i][assignTime[i]]:
                    break
                else:
                    cnt = 0
                    for ii in range(0,len(z)):
                        if ii == i:
                            continue
                        #print assignTime[ii],td[i],i,t,len(sortValueIndex),sortValueIndex[i][t],assignTime[ii],td[ii]							
                        if(assignTime[ii]<sortValueIndex[i][t] + td[i]/cons.timeStep	and sortValueIndex[i][t]< assignTime[ii]+td[ii]/cons.timeStep):
                            cnt = cnt + 1
                    if(cnt<c):
                        assignTime[i] = sortValueIndex[i][t]
    for i in range(0,len(z)):
        if assignTime[i]>=0:
            zinit[i][assignTime[i]+50] = 1
    initPath = cons.INITFILE.format(dat,mod)
    with open(initPath,'w') as initFile:
        initFile.write("zinit="+str(zinit)+";")

# solve one instance
def run(parameters):
    dat,mod,buffer = parameters
    c=0
    td=1
    cons = Constants_car()
    n = getNumRQ(dat,mod,c,td)
    print('{},{},{},{},{}'.format(c,td,dat,mod,buffer))
    print("Preparing inputs")
    value = readValue((c,td,dat,mod))
    sortValueIndex = sortValue(dat,mod,value)
    print( len(value))
    print(cons.timeNum)
    print(n)
    initWrite(dat,mod,[[0]*(cons.timeNum+50)]*n,value,sortValueIndex,c,[td]*n)
    print( "Start solving the problem")
    start = time.time()
    solvePAP(dat,mod,1,buffer,c,td)
    elapsed = (time.time()-start)
    print( "Solved in "+"%0.2f" % elapsed+"s")

if __name__=="__main__":
    SET = list(itertools.product(range(40901,40951),'1',['']))
    #SET = list(itertools.product(list((40223,40322,40323,40700,40709,40729,40739)),'1',['']))
    for s in SET:
        run(s)    

    #p = Pool(20)
    #p.map(run,SET)
	
    #run((10001,'1',''))

