# -*- coding: utf-8 -*-
"""
Created on June 22
Define constants
@author: ykaidi @modified mrr
"""

class Constants_car:
    #BUFFERPATH = "buffer/c={}/td={}/{}/"
    DATAPATH = 'dat/'
    #DELAYPATH = 'stochastic/delay_{}/c={}/td={}/'    
    #DELAYFILE = 'delay{}_{}_{}.dat'
    #DEMANDPATH = 'demand/c={}/td={}/'    
    INITFILE = 'dat/init{}_{}.dat'
    INPUTFILE = 'dat/mobin_{}.dat'
    MODPATH = 'mod/'
    PATHFILE = 'dat/path_{}.dat'
    PROCESSFILE = 'process{}.dat'
    #RELAXATIONPATH = 'stochastic/optimal_relaxation_{}{}/c={}/td={}/'
    #RELAXATIONPATH = 'stochastic/optimal_relaxation_{}{}/c={}/td={}/'
    #RETROSCPECTPATH = 'stochastic/optimal_in_retrospect_{}{}/c={}/td={}/'
    #SAMPLEPATH = 'stochastic/sample_{}/c={}/td={}/'
    SOLUTIONFILE = 'result{}.dat'
    SOLUTIONPATH = "solution/"    
    #SOLVEPATH = 'stochastic/solve_{}{}/c={}/td={}/'
    #STOCHASTICTPATH = 'stochastic/optimal_stochastic_{}{}/c={}/td={}/'
    SUMMARYFILE = '{}{}_{}_{}{}.dat'
    #SUMMARYPATH = 'stochastic/summary_{}{}/c={}/td={}/'
    VALUEFILE = 'dat/mobval_{}.dat'
    
    timeStep = 30
    timeNum = 48
    server = 'ivt'

    def __init__(self):
        if self.server == 'ivt':
            self.HOMEPATH = "/nas/mrocariu/dev/CAR/"
            self.CPLEXPATH = "/nas/mrocariu/CPLEX_Studio1263/opl/bin/x86-64_linux/"
        elif self.server == 'euler':
            self.CPLEXPATH = "/cluster/home/ykaidi/ibm/ILOG/CPLEX_Studio128/opl/bin/x86-64_linux/"
            self.HOMEPATH = "/cluster/home/ykaidi/PAP/dataset2/"
        else:
            self.CPLEXPATH = "C:/Program Files/ibm/ILOG/CPLEX_Studio1271/opl/bin/x64_win64/"
            self.HOMEPATH = "C:/Users/ykaidi/Dropbox/Research/Omega2018/new_codes/dataset2/"
            
    def getDist(self,att):
        if att == 'low':
            return {-3:0.05, -2:0.10, -1:0.15, 0:0.40, 1:0.15, 2:0.10, 3:0.05}
        else:
            return {-3:0.14, -2:0.14, -1:0.14, 0:0.16, 1:0.14, 2:0.14, 3:0.14}
