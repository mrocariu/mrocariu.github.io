// -------------------------------------------------------------- -*- C++ -*---------
// File: stw.cpp
// --------------------------------------------------------------------------
// Author: Mireia Roca-Riu
// Creation Date: April 2014
// --------------------------------------------------------------------------
//
// Solve a Model of Scheduling with Time Windows of Booked Parking Slots
// 
// Cplex enforced with Subtour elimination Constraints when violated in LP relaxation
//
// Call Program with two files Model and Data files to construct OPLModel .mod and .dat
// For instance:
// in new location
// ./STW  model.mod data.dat > results.txt &
// ./STW /home/mroca/bridgestone/Mireia/SubtourCode/STW/data/Model.mod /home/mroca/bridgestone/Mireia/SubtourCode/STW/data/Data.dat > results.txt &
/////////////////////////////////////////////////////////////////////////////////////

#include <ilopl/iloopl.h>
#include <sstream>
#include <iostream>
#include <fstream>
#include <cmath>
#include <vector>

using namespace std;

const double epsilonf = 0.00000001;
const double epsilon = 0.2;

typedef std::vector<double> vec;
typedef std::vector<vec> mat;
typedef std::vector<int> veci;
//////////////////////////////////
IloInt nodep2;


////////////////////////////////////////////////////////////////////////////////
// Performs the Edmond-Karp Algorithm and returns the maximum flow between
// 's' and 't'. The algorithm also remembers the conected component that
// contains 's' in the 0-1 array 'visited'
double maxFlowAndCut(int s, int t, int& NN, veci& queue, veci& previous, veci& visited, mat& capacityMatrix, mat& currentFlowMatrix ){
    int		i,j;							// index variables for loops
    int		u,v;                            // index variables for nodes
    int		queueIndex, queueSize;          // just for use an array as a queue
    double	flow;							// the augmenting flow
    double	maxFlow = 0.0;                  // the total amount of flow

    // initialize the 'currentFlowMatrix'
    for (i=0; i<NN; i++) {
        for (j=0; j<NN; j++) {
        	currentFlowMatrix[i][j] = 0.0;
		}
        queue[i]=0;
        previous[i]=0;
        visited[i]=0;
	}

    // perform as many flow augmentations as you can!
    flow = 1.0;                                     // this is just to start the loop
    while (flow > epsilonf ) {
        flow = 0.0;
        // initialize everything else!
		for (i=0; i<NN; i++) {visited[i]=0;}        // nobody has been visited yet
        visited[s] = 1;                             //  ...nobody but 's'
        queue[0] = s;                               //  that is already in the queue
        queueSize = 1;                              // the queue contains 1 element
        queueIndex = 0;                             // next element to leave the queue

        // perform a BFS to find a augmenting path between 's' and 't'
        while (queueIndex < queueSize){
            u = queue[queueIndex];                  // get the next element
            queueIndex++;                           // update to get the next one
            // now look if you can extend the augmenting path from 'u' to any other 'v'
            for (v=0; v<NN; v++)
                if (visited[v]==0 && capacityMatrix[u][v]-currentFlowMatrix[u][v]>epsilonf) {
                    visited[v] = 1;                 // if you can, visit the new node
                    queue[queueSize] = v;           // put it in the queue
                    queueSize++;                    // update the queue size!
                    previous[v] = u;                // remeber where you come from
                    if (v==t) break;                // and avoid do extra work!
                }

            // now, before continue, check if we have finished the BFS!
            if (visited[t] == 1) {
                // we are going to trace back our steps looking for how much flow we can send
                v = t;
                u = previous[t];
                flow = capacityMatrix[u][v]-currentFlowMatrix[u][v];
                while (u!=s) {
                    v = u;
                    u = previous[v];
                    if (flow > capacityMatrix[u][v]-currentFlowMatrix[u][v] + 0.001 )
                        flow = capacityMatrix[u][v]-currentFlowMatrix[u][v];
                }
                // now we can update the currentFlowMatrix with that amount of flow
                v = t;
                u = previous[t];
                currentFlowMatrix[u][v] += flow; // we add the flow in one direction
                currentFlowMatrix[v][u] -= flow; // and remove it from the other one!
                while (u!=s) {
                    v = u;
                    u = previous[v];
                    currentFlowMatrix[u][v] += flow; // we add the flow in one direction
                    currentFlowMatrix[v][u] -= flow; // and remove it from the other one!
                }
                maxFlow += flow;                    // we have improved so we update
                break;                              // avoid do extra work!
            }
        }
  }
    return maxFlow;
}

////////////////////////////////////////////////////////////////////////////////
// Usercut defined by a MACRO ILOUSERCUTCALLBACKk
// k=1 because we only need one parameter to enter the callback a file for saving callback information named /fitxer/
// k=2 because we need two parameters to enter the callback, a file and IloOplModel for extracting variables
// k=3 because we finally need three parameters, another file for saving information

ILOUSERCUTCALLBACK3(usercutcallbackinfo, ofstream&, fitxer, IloOplModel, stw, ofstream&, fitxerv){

	// Only apply cuts when callback is called once CPLEX stopped generating cuts at node. Not during the cut loop for avoiding too many calls
	if(isAfterCutLoop()){
		fitxer << nodep2 << " ";
		fitxerv << nodep2 << endl;
		int nodes;
		nodes=getNnodes();
		if(nodep2<1){
        // Other frequencies to call the callback
		//if(nodep2<250 || (nodes % 1500 <10)){
			IloEnv env = getEnv(); // Get the environment

			//if(getNnodes()<2500){ //&& hasIncumbent()){

                // Extract Variable T from IloOplModel
				IloNumVarMap Tc = stw.getElement("T").asNumVarMap();
				IloNumVarArray Tcc=Tc.asNewNumVarArray(); // Extract the whole array
				IloNumArray T(env, Tcc.getSize());
				getValues(T, Tcc);

				// Extract Variable x from IloOplModel
				IloIntVarMap xc = stw.getElement("x").asIntVarMap();
				IloIntVarArray xcc=xc.asNewIntVarArray(); // Extract the whole array
				IloNumArray x(env, xcc.getSize());
				getValues(x, xcc);


				// Inclusion of Subtour Elimination Constraints
				// STEP1. Get information from the solution vector from the LP relaxation

				// Node and Objective Value of the Relaxation
				fitxer << getNnodes() << " " << getNremainingNodes() << " " << getObjValue() ;//<< endl;

                //fitxer << getNcols()  << " " << getNrows() << endl;
				// Write Variables x and T
				//fitxer << x <<endl;
				//fitxer << T << endl << endl;

				// Variable Size of Matrix Problem
				int NN, xx;
				NN=T.getSize()+1;
				xx=x.getSize();

				// Variable Declaration for MaxFlowMinCut Algorithm
				std::vector<int> queue(NN);
				std::vector<int> previous(NN);
				std::vector<int> visited(NN);
				std::vector<std::vector <double> > capacityMatrix(NN,std::vector<double>(NN));
				std::vector<std::vector <double> > currentFlowMatrix(NN,std::vector<double>(NN));

				int rows=NN;
				int cols=rows;
				int k=0;
				// Build capacity Matrix from solution X for MaxFlow
				int i=0,j=0;
                // Print check information
				//fitxer << "NN= " << NN <<endl;
				//fitxer << "xx= " << xx <<endl;
				//for(i=1; i<x.getSize(); i++){
				//	fitxer << x[i] <<endl;
				//}

				for(i=1; i<NN; i++){
					for(j=1; j<NN; j++){
						if (i==j){

							 capacityMatrix[i][j]=0;
						}else{
							 capacityMatrix[i][j]=abs(x[k]);
							 k=k+1;
						}
						currentFlowMatrix[i][j]=0.0;
						//fitxer << i <<" & "<< j << endl;
					 }
				 }
            
                 // Inicialize matrix with values from x or zero
				 capacityMatrix[0][0]=0;
				 currentFlowMatrix[0][0]=0;
				 for(i=1; i<NN; i++){
					 capacityMatrix[0][i]=abs(x[k]);
					 currentFlowMatrix[0][i]=0.0;
					 k=k+1;
				 }
				 for(i=1; i<NN; i++){
						 capacityMatrix[i][0]=abs(x[k]);
						 currentFlowMatrix[i][0]=0.0;
						 k=k+1;
				 }

			// 	   Write capacity Matrix as a check
			//     fitxer << "CapacityMAtrix" << endl;
			//     for(i=0; i<NN; i++){
			//    	 for(j=0; j<NN; j++){
			//    		 fitxer << capacityMatrix[i][j] << " ";
			//    	 }
			//    	 fitxer << endl;
			//     }

            // Prepare the rest for MaxFlow computations

			// STEP2A. Find a cut trying all s,t pairs until one is found
			// the cut is saved in the vector visited

			//     int s, t;
			//     double mfac;
			//     bool cut=0;
			//     s=0;
			//     while(cut==0 && s<rows){
			//     //for(s=0; s<rows; s++){
			//    	 for(t=s+1; t<cols; t++){
			//    		 mfac=maxFlowAndCut(s,t,NN, queue, previous, visited, capacityMatrix, currentFlowMatrix);
			//    		 if(mfac+epsilon <1.0){
			//    			 fitxer << "subtour found " << s << " " << t << " " << mfac<< endl;
			//    			 for(i=0; i<rows; i++){
			//    				 fitxer << visited[i] << " ";
			//    			 }
			//    			 fitxer << endl;
			//    			 cut=1;
			//    			 break; // should break
			//    		 }
			//    	 }
			//     	 s=s+1;
			//     }
				// double mfac,mfaci;
			//     bool cut=0;
			//     int s=0;
			//     int t;
			//	 while(cut==0 && s<rows){
			//			      //for(s=0; s<rows; s++){
			//			     	 for(t=s+1; t<cols; t++){
			//			     		 mfac=maxFlowAndCut(s,t,NN, queue, previous, visited, capacityMatrix, currentFlowMatrix);
			//
			//			     		 //if(mfac+epsilon <1.0){
			//			     			 fitxer << "Maxflow between " << s << " " << t << " " << mfac<< endl;
			//			            	 for (i=0; i<NN; i++) {fitxer << visited[i];}
			//
			//				     		 mfaci=maxFlowAndCut(t,s,NN, queue, previous, visited, capacityMatrix, currentFlowMatrix);
			//			     			 fitxer << "Maxflow between " << t << " " << s << " " << mfaci<< endl;
			//			            	 for (i=0; i<NN; i++) {fitxer << visited[i];}
			//
			//
			//			     		 //}
			//			     	 }
			//			      	 s=s+1;
			//			      }

				// STEP2B. Find a cut while computing MinimumCut Tree with Gusfield
				// Stop computing the tree when a violated cut is found

                int		s,t;						// source and sink nodes
                int ms,mt; 							// source and sink nodes of maxflow
                double	auxFlow;						// aux variable to make a switch
                bool cut=0; 							// indicates when the cut has been found. Once found we stop searching
                double maxflowtemp=0;
				std::vector<int> GHtree(NN);
				std::vector<double> GHflow(NN);


				 // initialize everything
				 for (i=0; i<NN; i++) {                 // the starting tree is star-like
					 GHtree[i] = 0;                     //  with the '0' as central node
					 GHflow[i] = 0.0;                   //  and 0 flow in each edge
				 }

				 // visit the nodes and update 'pre' and 'flow'
				 s=1;
				 while(cut==0 && s<rows){
				 //for (s=1; s<NN; s++) {                      // the '0' node is already 'visited'
					for (i=0; i<NN; i++) {visited[i] = 0;}  // 'clean' the visited array  (just in case)
					 // in this iteration we are going to update the edge 's-pre[s]'
					 t = GHtree[s];
					 GHflow[s] = maxFlowAndCut(s,t,NN, queue, previous, visited, capacityMatrix, currentFlowMatrix);
					 maxflowtemp=GHflow[s];
					 ms=s;
					 mt=t;

					 //if (DEBUG>=3) printf("\t\t\tGH-Flow(%d): %f\n", s,GHflow[s]);

					 //fitxer << "GH-Flow " << s << " " << GHflow[s] <<endl;

					 // we have to update all the nodes connected with 't' that are on the 's' side
					 for (i=0; i<NN; i++) {
						 if (visited[i]==1  &&  i!=s  &&  GHtree[i]==t) {
							 GHtree[i] = s;
						}
					}

					 // if the predecessor of 't' is in the connected component of 's' (='X')
					 // we must swich the direction of the 's'-'t' link and the 's'-'t' flow!
					 if (visited[GHtree[t]] == 1) {
						 GHtree[s] = GHtree[t];
						 GHtree[t] = s;
						 auxFlow = GHflow[s];
						 GHflow[s] = GHflow[t];
						 GHflow[t] = auxFlow;
					 }

					 if (maxflowtemp+epsilon < 1){
						 //fitxer << "Subtour found "<< s <<" "<< t <<" "<< maxflowtemp << endl;
						 //fitxer << "Subtour found "<< ms <<" "<< mt <<" "<< maxFlowAndCut(mt,ms,NN, queue, previous, visited, capacityMatrix, currentFlowMatrix) << endl;
						 //for (i=0; i<NN; i++) {fitxer << visited[i];}
						 //fitxer << endl;
						 cut=1;
						 break;
					 }
					 s=s+1;
				 }




				 // STEP3. Write and add the cut
				if(cut==1){
					//for (i=0; i<NN; i++) {fitxer << visited[i];}
					//fitxer << endl;
					fitxer << " 1" << endl; //meaning 1 subtour
					IloExpr subeq(env); // Create a new expression in env environment

					 // From vector visited, write the expression
					 // We need to use the subset that does not contain the depot
					 // If visited[0]=0, then we go for 1
					 // If visited[0]=1, then we go for 0
					 subeq=xcc[0]; //It can not be initialized at zero, at the end, it is -xcc[0]
					 int indexi;
					 int indexj;
					 int subsetsize=0;
					 int set=visited[0];
					 int Nx;
					 double check=0;
					 double checkb=0;
					 Nx=x.getSize();
				//   cout << "Nx size " << Nx << endl;
				//     for (i=0;i<Nx;i++){
				//    	 subeq=subeq+xcc[i];
				//     }
					 for(s=0; s<rows; s++){
							 for(t=s+1; t<cols; t++){
								 if(visited[s]!=set && visited[t]!=set){
									 if (s==0){
										 indexi=(NN-1)*(NN-2)+t-1; //x[0,t]
										 indexj=(NN-1)*(NN-2)+NN-1+t-1; //x[t,0]


									 }else{
										 indexi=(NN-2)*(s-1)+t-2; //x[s,t], s < t always as we follow indexes
										 indexj=(NN-2)*(t-1)+s-1;//x[t,s]
									 }
									 //fitxer << s << ""<< t << " indexi= " << indexi << "indexj= " << indexj;
									 subeq=subeq+xcc[indexi]+xcc[indexj];
									 check=check+x[indexi]+x[indexj];
									 checkb=checkb+ capacityMatrix[s][t]+capacityMatrix[t][s];
								 }
							 }
					 }
					 for(s=0; s<rows; s++){
						 if(visited[s]!=set){
							 subsetsize=subsetsize+1;
						 }
					 }
					 //fitxer << " subsetsize " << subsetsize << endl;
					 //fitxer << "sumx value " << check << endl;
					 //fitxer << "sumcapacity value " << checkb << endl;

					 if (check<=subsetsize-1){
						 fitxer << "Error Check"<<endl;
					 }
					 subeq=subeq-xcc[0]; // xcc[0] was used to initialize the subeq
					 IloRange range(env,-IloInfinity,subeq,subsetsize-1); // Create a new constraint -Inf<subeq<2


					// model.add(range) //Method for IloModels
					// add(IloConstraint con, IloCplex::CutManagement purgeable=UseCutForce) //OrUseCutFilter
					// IloCplex::CutManagement purgeable= IloCplex::CutManagement::UseCutForce;
					//add(range, purgeable);

					 add(range); //Use default value of purgeable=UseCutForce
				}else
				{
				fitxer <<" 0" << endl;
				}
		}else{
			fitxer <<"0 0 0 0" << endl;
		}

	}
}

////////////////////////////////////////////////////////////////////////////////
// Usercut defined by a MACRO ILONODECALLBAK2
// k=1 because we only need one parameter to enter the callback a file for saving callback information named /fitxer/
// k=2 because we need a new variable in and out to record the depth of the node that will be analyzed next
ILONODECALLBACK1(nodecallback, ofstream&, fitxer){
	nodep2=nodep2+1;
	IloInt64 nextnode=0;
	fitxer << nextnode << endl;
	nodep2=getDepth(nextnode);
	fitxer << nodep2 <<endl;
}


int main(int argc,char* argv[]) {

	int status = 127;
	ofstream file, fileo, fileg, filep,filev;
	file.open (argv[6]);
	filev.open("Depnode.txt");
	fileo.open (argv[3]);
	fileg.open (argv[5],std::fstream::app);
	filep.open (argv[4],std::fstream::app);

	nodep2=0;

	if (argc==7){ //Check if the number of elements when calling the function is correct.

		IloEnv env;

		try {

			// Construct IloOpl Model from a .mod file .mod and a .dat file external called by command line
			IloOplErrorHandler handler(env,cout);
			//IloOplModelSource modelSource(env, "/home/mroca/workspace/STW/data/Model.mod");
			IloOplModelSource modelSource(env, argv[1]);
			IloOplSettings settings(env,handler);
			IloOplModelDefinition def(modelSource,settings);
			IloCplex cplex(env);

			// Parameter Adjustment
			cplex.setParam(IloCplex::TiLim,3600);
			cplex.setParam(IloCplex::Threads,1);

		    IloOplModel opl(def,cplex);
			// IloOplDataSource dataSource(env, "/home/mroca/workspace/STW/data/Data.dat");
		    IloOplDataSource dataSource(env, argv[2]);
			opl.addDataSource(dataSource);
			opl.generate();


			// Extract an IloModel from an IloOplModel
			IloModel mod;
			mod = opl.getCplex().getModel();


// ----------------------------------------------------------------------------------------------------
// -----------------------------Generation of Cuts in the main Program --------------------------------
// ----------------------------------------------------------------------------------------------------


			// Extract Variable T from IloOplModel
			//IloNumVarMap Tc = opl.getElement("T").asNumVarMap();
			//IloNumVar Tc1=Tc.get((IloInt) 1); // Extract one element
			//IloNumVarArray Tcc=Tc.asNewNumVarArray(); // Extract the whole array

			// Create new Expression to include a new constraint in the model
			//IloExpr newconstraint(env);
			//newconstraint=Tc1;

			// Add to de IloModel a new constraint (IloRange), T>520
			//mod.add(IloRange(env, 520, newconstraint, IloInfinity));

			// Create second Expression to include a second constraint in the model
			//  IloExpr secconstraint(env);
			//secconstraint=Tcc[2]; //Note that c++ begins at zero

			// Add to de IloModel a second constraint (IloRange), T>550
			// mod.add(IloRange(env, 550, secconstraint, IloInfinity));

			// Extract Variable X from IloOplModel
			IloIntVarMap xc = opl.getElement("x").asIntVarMap();
			IloIntVarArray xcc=xc.asNewIntVarArray(); // Extract the whole array
			//file << "xx size" << xcc.getSize();

			//cout << xcc.getSize() << endl;
			//cout << xcc[1] << endl;
			//cout << Tcc[1] << endl;

			// Create third Expression to include a third constraint in the model
			//IloExpr thiconstraint(env);
			//thiconstraint= xcc[0] +xcc[1]+ xcc[2]; //Note that c++ begins at zero

			// Add to de IloModel a third constraint (IloRange), sum x <0.5. Limit sum of bool variables to be smaller than 0.5, then all zero
			//mod.add(IloRange(env, -IloInfinity, thiconstraint, 0.5));

// ------------------------------------------------------------------------------------------------------------

			// Include the callback the IloCplex
			cplex.use(usercutcallbackinfo(env,file,opl,filev));
			cplex.use(nodecallback(env,filev));
			IloBool sol=cplex.solve();
			if ( sol ) {
			    cout << endl
					<< "OBJECTIVE: " << fixed << setprecision(2) << opl.getCplex().getObjValue()
					<< endl;			IloExpr newconstraint(env);
			    opl.postProcess();

				// File Global
				IloOplElement idd = opl.getElement("Id");
				fileg << "Id=" << idd.asNum() << endl;
				fileg << "Cplex Status= "<< opl.getCplex().getCplexStatus()<<endl;
				fileg << "Cplex ObjValue= "<< opl.getCplex().getObjValue()<<endl;
				fileg << endl;

			    // File Output
			    fileo << "OBJECTIVE " << opl.getCplex().getObjValue() << endl;
				opl.printSolution(fileo);

				// File Plot
				IloOplElement nd = opl.getElement("n");
				IloOplElement cd = opl.getElement("c");
				filep << idd.asNum() << "\t";
				filep << nd.asNum() << "\t";
				filep << cd.asNum() << "\t";
				if (idd.asNum()<231 || (idd.asNum()>245 && idd.asNum()<256)){
					filep << "6\t";
				}else{
					filep << "10\t";
				}
				filep << opl.getCplex().getCplexStatus() << "\t";
				filep << sol << "\t"; // Cplex.solve()
				filep << opl.getCplex().getObjValue();
				filep << endl;

				status = 0;

			} else {
				cout << "No solution!" << endl;
				status = 1;

				// File Global
				IloOplElement idd = opl.getElement("Id");
				fileg << "Id=" << idd.asNum() << endl;
				fileg << "Cplex Status= "<< opl.getCplex().getCplexStatus()<<endl;
				fileg << "Cplex ObjValue= "<< opl.getCplex().getBestObjValue()<<endl;
				fileg << endl;

			    // File Output
				fileo << "OBJECTIVE " << "No Solution Found";//opl.getCplex().getObjValue() << endl;
				//opl.printSolution(fileo);

				// File Plot
				IloOplElement nd = opl.getElement("n");
				IloOplElement cd = opl.getElement("c");
				filep << idd.asNum() << "\t";
				filep << nd.asNum() << "\t";
				filep << cd.asNum() << "\t";
				if (idd.asNum()<231 || (idd.asNum()>245 && idd.asNum()<256)){
					filep << "6\t";
				}else{
					filep << "10\t";
				}
				filep << opl.getCplex().getCplexStatus() << "\t";
				filep << sol <<"\t"; // Cplex.solve()
				filep << "-1\t";
				filep << endl;


			}


			//fileo << x << endl;
			//fileo << T << endl;

			fileo.close();
			fileg.close();
			filep.close();
			file.close();
		} catch (IloOplException & e) {
			cout << "### OPL exception: " << e.getMessage() << endl;
		} catch( IloException & e ) {
			cout << "### CONCERT exception: ";
			e.print(cout);
			status = 2;
		} catch (...) {
			cout << "### UNEXPECTED ERROR ..." << endl;
			status = 3;
		}

		env.end();
		/// Write Output Files


		cout << endl << "--Goodbye--" << endl;
	} else {
		cout << endl << "Error. Input Arguments Should be 6" << endl;
	}
    return status;

}
