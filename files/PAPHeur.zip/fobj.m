% earliness-tardiness function
% evaluate objective function given the given feasible solution
function [fobj1,fobj2,fobj3,fobj4]=fobj(c,rq,T,tdab)

    TT=sum(T,2);

    % Evaluate solution under each model
    %%% MOD 1: Earliness/Tardiness
    
    fobj1=0;
    e=zeros(size(rq,2),1);
    for i=1:size(TT,1)    
        e(i)=max([0,tdab(2,i)-TT(i),TT(i)-tdab(3,i)]);
        fobj1=fobj1+e(i);
    end    
    
    %%% MOD 2: Min Max Earliness
    fobj2=max(e);
    
    %%% MOD 3: Earliness/Tardiness subject to max displ
    maxdispl=60;
    if fobj2>maxdispl
        fobj3=Inf;
    else
        fobj3=fobj1;
    end
    
    %%% MOD 4: Number of requests scheduled outside TW
    fobj4=sum(e~=0);
        