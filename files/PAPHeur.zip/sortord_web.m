%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INPUT DATA
% This file is no longer needed because generated data is already sorted in
% the right order
% c:place number
% sl:standard length of the time window
% tdab: td distribution time, a, b begin and end of time window

% assuming ordered requests with this order: 
% (1)   i<j if a(i)<a(j) elseif a(i)=a(j)
% (2)   i<j if b(i)<b(j) elseif b(i)=b(j)
% (3)   i<j if td(i)<td(j) elseif  indistict order

% OUTPUT DATA
% reordered tdab

% DATA LOAD
%     clear rq;
%     clear c tdab T rq;
%     load (['schedpark', num2str(k),'.mat']);    

% ORDER REQUESTS
    % a) ORDER BY INITIAL TIME WINDOW
    if ~issorted(tdab(2,:))
        [a,ia]=sort(tdab(2,:),2);
        tdabs=[tdab(1,ia);a;tdab(3,ia)];
    else
        tdabs=tdab;
    end
    
    % b) ORDER BY INITIAL FINAL WINDOW
    i=1;
    tdabss=tdabs;
    while i<size(tdabs,2)
        j=i+1;
        while tdabs(2,i)==tdabs(2,j) && j<size(tdabs,2)
            j=j+1;
        end
        if j>i+1
            j=j-1;
            [b,ib]=sort(tdabs(3,i:j),2);
            tdabss=[tdabss(1,1:i-1) tdabss(1,ib+i-1) tdabss(1,j+1:end);
            tdabss(2,1:i-1) tdabss(2,ib+i-1) tdabss(2,j+1:end);
            tdabss(3,1:i-1) tdabss(3,ib+i-1) tdabss(3,j+1:end)];           
            i=j+1;
        else
            i=j;
        end
    end
    
    % c) ORDER BY INITIAL TIME DURATION
    i=1;
    tdabsss=tdabss;
    while i<size(tdabs,2)
        j=i+1;
        while tdabss(3,i)==tdabss(3,j) && tdabss(2,i)==tdabss(2,j) && j<size(tdabs,2)
            j=j+1;
        end
        if j>i+1
            j=j-1;
            [b,ib]=sort(tdabss(1,i:j),2);
            tdabsss=[tdabsss(1,1:i-1) tdabsss(1,ib+i-1) tdabsss(1,j+1:end);
            tdabsss(2,1:i-1) tdabsss(2,ib+i-1) tdabsss(2,j+1:end);
            tdabsss(3,1:i-1) tdabsss(3,ib+i-1) tdabsss(3,j+1:end)];           
            i=j+1;
        else
            i=j;
        end
    end
    tdab=tdabsss;    