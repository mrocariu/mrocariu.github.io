
fod=fopen(['Improve_Heuristics M1234_4.txt'],'wt'); % outside file

for k=201:260
        
    load (['res/schedparksol', num2str(k),'.mat']);
    feasfound=0;
    iter=0;        
    [fobj1,fobj2,fobj3,fobj4]=fobj(c,rq,T,tdab);
    fobj1m=fobj1;
    fobj2m=fobj2;
    fobj3m=fobj3;
    fobj4m=fobj4;
    fobjmv=[fobj1m,fobj2m,fobj3m,fobj4m];
    TTT=T;
    fprintf('Instance %i: %i %i %i %i\n',k,fobj1,fobj2,fobj3,fobj4);
    fprintf(fod,'%i ',k);
    improve=1;
    for mod=1:4
%         fprintf('Model %i begins:\n',mod);
        T=TTT;
        fobjmm=fobjmv(mod);
        fobjm=fobjmm;
        improve=1;
        iter=1;
        while improve==1;

            improve=0;
            [Tf,fobjm]=mov(c,rq,T,tdab,mod);
%             fprintf('Iter %i %i %i\n',iter,fobjmm,fobjm);
 
            if fobjm<fobjmm
                %fprintf('Improve %i %i',k,mod);
                improve=1;
                T=Tf;
                fobjmm=fobjm;
            end
            iter=iter+1;
        end
        fprintf(fod,'%i ',fobjm);
    end
    fprintf(fod,'\n');
end

        
    
    
    
    
    
    
    