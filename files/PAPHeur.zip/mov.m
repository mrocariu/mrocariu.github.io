function [Tf,fobjm]=mov(c,rq,T,tdab,mod)
    [fobj1,fobj2,fobj3,fobj4]=fobj(c,rq,T,tdab);
    fobjv=[fobj1,fobj2,fobj3,fobj4];
    fobjm=fobjv(mod);
    Tf=T;
    for i=1:size(rq,2)
            % 1-PLACE CHANGE
            % Try to change each request with the previous/next request
            % Choose one random request of the solution to apply a movement
            % i=ceil(rand*size(rq,2));
            % If we choose a random request, it makes sense to check previous &
            % next
            % If we check all requests, it is enough check next only
            if i<size(rq,2) j=i+1; else j=i; end
            % previous
            ip=T(i,:)~=0;
            jp=T(j,:)~=0;
            ipp=T(i,ip);
            jpp=T(j,jp);
            % Mov1a next
            Ta=T;
            Ta(j,jp)=T(i,ip);
            Ta(i,ip)=jpp;

            % 2-PLACE CHANGE
            % Try to change all requests
            % next
            if i<size(rq,2)-1 j=i+2; else j=i; end
            ip=T(i,:)~=0;
            jp=T(j,:)~=0;
            ipp=T(i,ip);
            jpp=T(j,jp);
            % Mov2c next
            Tc=T;
            Tc(j,jp)=T(i,ip);
            Tc(i,ip)=jpp;

            % Check feasibility or adequate
            [Tfa,feasa]=neig(c,rq,Ta,tdab);
            [Tfc,feasc]=neig(c,rq,Tc,tdab);

            % Evaluate solutions
            [fobj1a,fobj2a,fobj3a,fobj4a]=fobj(c,rq,Tfa,tdab);
            [fobj1c,fobj2c,fobj3c,fobj4c]=fobj(c,rq,Tfc,tdab);
            fobja=[fobj1a,fobj2a,fobj3a,fobj4a];
            fobjc=[fobj1c,fobj2c,fobj3c,fobj4c];
           % fprintf('%i: %i %i %i %i\n',mod,fobj1a,fobj2a,fobj3a,fobj4a);
           % fprintf('%i: %i %i %i %i\n',mod,fobj1c,fobj2c,fobj3c,fobj4c);
%                 fprintf('%i:a %i %i %i %i\n',mod,fobj1a,fobj2a,fobj3a,fobj4a);
%                 fprintf('%i:c %i %i %i %i\n',mod,fobj1c,fobj2c,fobj3c,fobj4c);
            if fobja(mod)<=fobjm 
                fobjm=fobja(mod); 
                Tf=Tfa;
            end
            if fobjc(mod)<=fobjm 
                fobjm=fobjc(mod); 
                Tf=Tfc;
                
            end
    end
end