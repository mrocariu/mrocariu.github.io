%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% Greedy heuristic for STW %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% VERSI� 4 9/2/2015
% Data should come sorted

%%%% GREEDY HEURISTIC FOR ALL MODELS
 
% SOLVING Models 1,2,3,4
% Asign Orders satisfing time windows
% If there are available places and requests not served
% Assing first time request not served to first available place
% While place not finished or requests not served
% Assing new first time request not served to first available place
% End
% Once the BASIS criteria has asigned "feasible" or "not penalizing" requests.
% The other requests will be assigned in the final of the period of
% each place.
% IMPROVEMENT: requests not assigned can be assigned either before the
% beginnig of the interval or after.

% Output: File with the value of the objective function of each model for
% solution given by Heuritics proposed


fod=fopen(['Heuristics M1234.txt'],'wt'); % outside file

for k=201:260
% Load problem data
load (['dat/stw', num2str(k),'.mat']);    

    % Building a zero solution
    fid=fopen(['res/dataT',num2str(k),'.txt'],'wt'); % outside file
    % Zero Solution
    X=zeros(size(tdab,2)+1,size(tdab,2)+1);
    % MODEL 0 or BASIS
    T=zeros(size(tdab,2),c);
    % Requests not served
    rq=ones(1,size(tdab,2));
    oc=1; %places occupied

    % Building Feasible Solution with sorted criteria
    while (sum(rq~=0) && oc<=c)
        i=1; 
        while rq(i)==0 
            i=i+1; 
        end
        %asign first request
        T(i,oc)=tdab(2,i);
        X(1,i)=1;
        anti=i;
        rq(i)=0;
        i=i+1;
       while (sum(rq~=0) && i<=size(rq,2))
            % check feasibility restrictions
    %             if tdab(2,i)>T(anti,oc)+tdab(1,anti) % ventana temporal
    %             empieza m�s tarde del tiempo final anterior
            if rq(i)==0 

            else
                if tdab(2,i)>T(anti,oc)+tdab(1,anti) % ventana temporal empieza m�s tarde del tiempo final anterior                
                    T(i,oc)=tdab(2,i);
                    rq(i)=0;
    %                 pause;
                    X(anti+1,i)=1;
                    anti=i;
                elseif (tdab(2,i)<=T(anti,oc)+tdab(1,anti) && tdab(3,i)>=T(anti,oc)+tdab(1,anti)) % ventana temporal entre el tiempo solicitado
                    T(i,oc)=T(anti,oc)+tdab(1,anti);
                    rq(i)=0 ;  
                    X(anti+1,i)=1; 
                    anti=i;
    %                 pause;
                end
            end
            i=i+1;

        end
        % New place ocuppied
        oc=oc+1;
    end

    % Build solution with non-feasible assigned requests
    

    % Sort non-assigned requests
    % Which request will we assign
    [MT,NT]=sort(tdab(1,:)); %NT will have the order of assignment 
    i=1;
    while i<size(rq,2) && rq(NT(i))==0
        i=i+1;
    end
    while (sum(rq~=0) && i<=size(rq,2))
        
        % Where will we assign each request
        % After last served request
        [M,I]=max(T,[],1); % max time of usage place
        [N,J]=min(M,[],2);  % place which is first free
        %Before first served request
        tmp=T;
        tmp(tmp==0)=Inf;
        [UM,UI]=min(tmp,[],1); % min time of usage place
        [UN,UJ]=max(UM,[],2);  % place which is last used
        
        % Before or after
        % Assign the request NT(i) to place 
        
        Ttmax=T(I(J),J)+tdab(1,I(J));
        Ttmin=T(UI(UJ),UJ)-tdab(1,UI(UJ));
        if tdab(2,NT(i))-Ttmin <= Ttmax-tdab(3,NT(i))
            %assign before
            T(NT(i),J)=T(UI(UJ),UJ)-tdab(1,UI(UJ));
            X(NT(i)+1,UI(UJ)+1)=1;    
            X(1,UI(UJ)+1)=0;
            X(1,NT(i))=1;
        else
            %assign after
            T(NT(i),J)=T(I(J),J)+tdab(1,I(J));
            X(I(J)+1,NT(i))=1;     
        end
        rq(NT(i))=0;
        i=i+1;      
        while i<size(rq,2) && rq(NT(i))==0
            i=i+1;
        end
    end
    % Close X 
    [M,I]=max(T,[],1);
    X(I+1,size(tdab,2)+1)=1;
    
%     % check variable T & print
      TT=sum(T,2);
%     fprintf(fod,'%d\n',TT);
%     % Print variable X
%     for j=1:(size(rq,2))
%         fprintf(fod,'%d\t%d\t%d\n',0,j,X(1,j));
%     end
%     for i=2:(size(rq,2)+1)
%         for j=1:(size(rq,2))
%             if  (i-1)~=j % tdab(2,i-1)<=tdab(3,j)
%               fprintf(fod,'%d\t%d\t%d\n',i-1,j,X(i,j));
% %             else
% %                 fprintf(fod,'�\t',X(i,j));
%             end
%         end
%         fprintf(fod,'%d\t%d\t%d\n',i-1,j+1,X(i,j+1));        
% %         fprintf(fod,'\n');        
%    end     
    
    % Evaluate solution under each model
    %%% MOD 1: Earliness/Tardiness
    fobj1=0;
    e=zeros(size(rq,2),1);
    for i=1:size(TT,1)    
        e(i)=max([0,tdab(2,i)-TT(i),TT(i)-tdab(3,i)]);
        fobj1=fobj1+e(i);
    end    
    
    %%% MOD 2: Min Max Earliness
    fobj2=max(e);
    
    %%% MOD 3: Earliness/Tardiness subject to max displ
    maxdispl=60;
    if fobj2>maxdispl
        fobj3=Inf;
    else
        fobj3=fobj1;
    end
    
    %%% MOD 4: Number of requests scheduled outside TW
    fobj4=sum(e~=0);
    
    
    
    fprintf(fod,'%i %i %i %i %i\n',k,fobj1,fobj2,fobj3,fobj4);
    savefile=['res/schedparksol', num2str(k),'.mat'];
    save(savefile,'c','tdab','T','rq');
end
fclose(fod);
